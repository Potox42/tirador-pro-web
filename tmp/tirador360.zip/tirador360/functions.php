<?php
if (!defined('ABSPATH')) exit;

add_action('after_setup_theme', function () {
  add_theme_support('title-tag');
  add_theme_support('woocommerce');
  add_theme_support('html5', ['search-form', 'comment-form', 'gallery', 'caption', 'style', 'script']);
  register_nav_menus(['principal' => 'Menú principal']);
});

add_action('wp_enqueue_scripts', function () {
  wp_enqueue_style('t360-fuente', 'https://fonts.googleapis.com/css2?family=Exo+2:wght@400;500;600;700;800&display=swap', [], null);
  wp_enqueue_style('t360', get_stylesheet_uri(), [], wp_get_theme()->get('Version'));
});

// Icono de la web y del iPhone.
add_action('wp_head', function () {
  $u = get_template_directory_uri() . '/assets/img/';
  echo '<link rel="icon" type="image/svg+xml" href="' . esc_url($u . 'icono.svg') . "\">\n";
  echo '<link rel="apple-touch-icon" href="' . esc_url($u . 'icono-180.png') . "\">\n";
  echo "<meta name=\"theme-color\" content=\"#060D18\">\n";
});

// Mientras la web esté en la dirección provisional, que Google no la indexe.
// Al pasar a tirador360.es, cambiar a false.
const T360_EN_OBRAS = true;
add_action('wp_head', function () {
  if (T360_EN_OBRAS) echo "<meta name=\"robots\" content=\"noindex,nofollow\">\n";
}, 1);

// ================= Tienda =================
// SKU de los productos (así no dependemos de los ID).
const T360_SKU_BASICA = 'T360-BASICA';
const T360_SKU_PRO = 'T360-PRO';
const T360_SKU_SUBIR = 'T360-SUBIR-PRO';
const T360_URL_APP = 'https://potox42.github.io/app-armas/';

function t360_id_sku($sku) { return function_exists('wc_get_product_id_by_sku') ? (int) wc_get_product_id_by_sku($sku) : 0; }

function t360_carrito_tiene($sku) {
  if (!function_exists('WC') || !WC()->cart) return false;
  $id = t360_id_sku($sku);
  foreach (WC()->cart->get_cart() as $linea) if ((int) $linea['product_id'] === $id) return true;
  return false;
}

// Una licencia por pedido: al añadir un producto se vacía el carrito y se va directo al pago.
add_filter('woocommerce_add_to_cart_validation', function ($ok) {
  if ($ok && WC()->cart) WC()->cart->empty_cart();
  return $ok;
}, 1);
add_filter('woocommerce_add_to_cart_redirect', function () { return wc_get_checkout_url(); });
add_filter('wc_add_to_cart_message_html', '__return_empty_string');

// Los productos son virtuales: el pedido pagado pasa solo a «Completado» y así se envía el código.
add_filter('woocommerce_order_item_needs_processing', function ($necesita, $producto) {
  return ($producto && $producto->is_virtual()) ? false : $necesita;
}, 10, 2);

// Producto digital: en el pago solo pedimos lo necesario (sin dirección ni notas de entrega).
add_filter('woocommerce_enable_order_notes_field', '__return_false');
add_filter('woocommerce_checkout_fields', function ($campos) {
  foreach (['billing_company', 'billing_address_1', 'billing_address_2', 'billing_city', 'billing_state', 'billing_postcode'] as $k) unset($campos['billing'][$k]);
  if (isset($campos['billing']['billing_phone'])) $campos['billing']['billing_phone']['required'] = false;
  return $campos;
});

// Casilla de condiciones con la renuncia al desistimiento (art. 103 m TRLGDCU).
add_filter('woocommerce_get_terms_and_conditions_checkbox_text', function () {
  return 'He leído y acepto los [terms]. Solicito recibir mi código de licencia ahora mismo y entiendo que, una vez recibido, pierdo el derecho de desistimiento.';
});

// Pasar de Básica a Pro: hay que dar el código Básica.
add_action('woocommerce_after_order_notes', function ($checkout) {
  if (!t360_carrito_tiene(T360_SKU_SUBIR)) return;
  echo '<div class="t360-campo-subir"><h3>Tu código de Tirador 360 Básica</h3>';
  woocommerce_form_field('t360_codigo_basica', [
    'type' => 'text', 'required' => true, 'label' => 'Código Básica',
    'placeholder' => 'T360B-XXXX-XXXX-XXXX',
    'description' => 'Lo tienes en el correo de tu compra y en la app, en Perfil.',
  ], $checkout->get_value('t360_codigo_basica'));
  echo '</div>';
});

function t360_basica_valida($codigo) {
  if (!function_exists('lmfwc_get_license')) return 'No se ha podido comprobar el código. Escríbenos a rgg@ozono3.es.';
  $lic = lmfwc_get_license($codigo);
  if (!$lic || (int) $lic->getProductId() !== t360_id_sku(T360_SKU_BASICA) || !$lic->getOrderId()) {
    return 'Ese código no corresponde a ninguna licencia Básica. Revísalo (empieza por T360B-).';
  }
  $usado = wc_get_orders(['limit' => 1, 'status' => ['processing', 'completed'], 'return' => 'ids',
    'meta_query' => [['key' => '_t360_codigo_basica', 'value' => $codigo]]]);
  if ($usado) return 'Ese código Básica ya se ha usado para pasar a Pro.';
  return '';
}

add_action('woocommerce_checkout_process', function () {
  if (!t360_carrito_tiene(T360_SKU_SUBIR)) return;
  $codigo = strtoupper(trim(sanitize_text_field(wp_unslash($_POST['t360_codigo_basica'] ?? ''))));
  if ($codigo === '') { wc_add_notice('Escribe tu código de Tirador 360 Básica.', 'error'); return; }
  $error = t360_basica_valida($codigo);
  if ($error) wc_add_notice($error, 'error');
});

add_action('woocommerce_checkout_create_order', function ($order) {
  if (!empty($_POST['t360_codigo_basica'])) {
    $order->update_meta_data('_t360_codigo_basica', strtoupper(trim(sanitize_text_field(wp_unslash($_POST['t360_codigo_basica'])))));
  }
});

// Al completarse el paso a Pro, la licencia Básica queda desactivada (el cliente usa el código Pro nuevo).
add_action('woocommerce_order_status_completed', function ($order_id) {
  $order = wc_get_order($order_id);
  $codigo = $order ? $order->get_meta('_t360_codigo_basica') : '';
  if ($codigo && function_exists('lmfwc_update_license')) {
    try { lmfwc_update_license($codigo, ['status' => 4]); $order->add_order_note('Licencia Básica ' . $codigo . ' desactivada por el paso a Pro.'); }
    catch (\Throwable $e) { $order->add_order_note('No se pudo desactivar la licencia Básica ' . $codigo . ': ' . $e->getMessage()); }
  }
});

add_action('woocommerce_admin_order_data_after_billing_address', function ($order) {
  $c = $order->get_meta('_t360_codigo_basica');
  if ($c) echo '<p><strong>Código Básica (paso a Pro):</strong> ' . esc_html($c) . '</p>';
});

// Correo de pedido completado: cómo instalar la app y confirmación de la renuncia al desistimiento.
add_action('woocommerce_email_before_order_table', function ($order, $admin, $texto_plano, $email) {
  if ($admin || !$email || $email->id !== 'customer_completed_order') return;
  $pasos = [
    'Abre en tu móvil <a href="' . esc_url(T360_URL_APP) . '">' . esc_html(T360_URL_APP) . '</a> (en iPhone con Safari; en Android con Chrome).',
    'Añádela a la pantalla de inicio: en iPhone, botón Compartir › «Añadir a pantalla de inicio»; en Android, menú ⋮ › «Instalar aplicación».',
    'Abre Tirador 360 desde el icono, ve a Perfil y escribe tu código de licencia (lo tienes más abajo en este correo).',
  ];
  if ($texto_plano) {
    echo "CÓMO EMPEZAR\n";
    foreach ($pasos as $i => $p) echo ($i + 1) . '. ' . wp_strip_all_tags($p) . "\n";
    echo "\nConfirmamos que solicitaste recibir el código en el momento de la compra y que, por tratarse de contenido digital ya entregado, no se aplica el derecho de desistimiento.\n\n";
    return;
  }
  echo '<div style="background:#0D1D35;border:1px solid #1F3A5C;border-radius:14px;padding:20px 22px;margin:8px 0 22px">';
  echo '<p style="margin:0 0 14px;font-size:19px;font-weight:800;color:#22D3FF">Cómo empezar en 3 pasos</p>';
  echo '<table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%">';
  foreach ($pasos as $i => $p) {
    echo '<tr><td valign="top" style="width:40px;padding:0 0 12px;border:0;background:transparent"><div style="width:30px;height:30px;line-height:30px;border-radius:15px;background:#22D3FF;color:#04101E;text-align:center;font-weight:800;font-size:15px">' . ($i + 1) . '</div></td>';
    echo '<td valign="top" style="padding:4px 0 12px;border:0;background:transparent;color:#D5E1EE">' . $p . '</td></tr>';
  }
  echo '</table>';
  echo '<p style="margin:6px 0 0;padding:12px 14px;background:#060D18;border-radius:10px;font-size:14px;color:#B5C6D8">📱 Tu licencia funciona en un móvil. Si cambias de teléfono, haz una copia de seguridad, pulsa «Liberar licencia» en Perfil y activa el mismo código en el móvil nuevo.</p></div>';
  echo '<p style="font-size:12px;color:#6F87A0">Confirmamos que solicitaste recibir el código en el momento de la compra y que, por tratarse de contenido digital ya entregado, no se aplica el derecho de desistimiento.</p>';
}, 10, 4);

// ================= Recomendados =================
// Cada compra de Básica o Pro genera un código AMIGO-XXXXX: 10 % de descuento en Básica o Pro,
// válido para 3 compras de otras personas. Se envía en el correo de compra y la app lo comparte.
function t360_crear_codigo_amigo($order) {
  // El correo y el cambio de estado llegan con copias distintas del pedido: se mira el guardado.
  static $hechos = [];
  $id = $order->get_id();
  if (isset($hechos[$id])) return $hechos[$id];
  $guardado = wc_get_order($id);
  $ya = $guardado ? $guardado->get_meta('_t360_codigo_amigo') : '';
  if ($ya) return $hechos[$id] = $ya;
  $order = $guardado ?: $order;
  $ids = [t360_id_sku(T360_SKU_BASICA), t360_id_sku(T360_SKU_PRO)];
  $compra = false;
  foreach ($order->get_items() as $item) if (in_array((int) $item->get_product_id(), $ids, true)) $compra = true;
  if (!$compra) return $hechos[$id] = '';
  $letras = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  do {
    $codigo = 'AMIGO-';
    for ($i = 0; $i < 5; $i++) $codigo .= $letras[random_int(0, strlen($letras) - 1)];
  } while (wc_get_coupon_id_by_code($codigo));
  $cupon = new WC_Coupon();
  $cupon->set_code($codigo);
  $cupon->set_discount_type('percent');
  $cupon->set_amount(10);
  $cupon->set_usage_limit(3);
  $cupon->set_usage_limit_per_user(1);
  $cupon->set_individual_use(true);
  $cupon->set_product_ids(array_filter($ids));
  $cupon->set_email_restrictions([]);
  $cupon->set_description('Recomendado por el pedido #' . $order->get_id() . ' (' . $order->get_billing_email() . ')');
  $cupon->update_meta_data('_t360_pedido_origen', $order->get_id());
  $cupon->update_meta_data('_t360_email_origen', strtolower($order->get_billing_email()));
  $cupon->save();
  $order->update_meta_data('_t360_codigo_amigo', $codigo);
  $order->save();
  $order->add_order_note('Código de recomendado creado: ' . $codigo);
  return $hechos[$id] = $codigo;
}
// Prioridad 5: antes de que salga el correo de pedido completado.
add_action('woocommerce_order_status_completed', function ($order_id) {
  $order = wc_get_order($order_id);
  if ($order) t360_crear_codigo_amigo($order);
}, 5);

// Nadie puede usar su propio código.
add_filter('woocommerce_coupon_is_valid', function ($valido, $cupon) {
  $origen = $cupon->get_meta('_t360_email_origen');
  if (!$valido || !$origen || !WC()->customer) return $valido;
  $email = strtolower((string) WC()->customer->get_billing_email());
  if ($email && $email === $origen) throw new Exception('No puedes usar tu propio código de recomendado.');
  return $valido;
}, 10, 2);

// Enlace con ?amigo=CODIGO: se guarda y se aplica solo al pagar.
add_action('template_redirect', function () {
  if (empty($_GET['amigo']) || !function_exists('WC') || !WC()->session) return;
  $codigo = strtoupper(sanitize_text_field(wp_unslash($_GET['amigo'])));
  if (!preg_match('/^AMIGO-[A-Z0-9]{5}$/', $codigo)) return;
  if (!WC()->session->has_session()) WC()->session->set_customer_session_cookie(true);
  WC()->session->set('t360_amigo', $codigo);
});
add_action('woocommerce_before_checkout_form', function () {
  if (!WC()->session || !WC()->cart) return;
  $codigo = WC()->session->get('t360_amigo');
  if (!$codigo || WC()->cart->has_discount($codigo) || t360_carrito_tiene(T360_SKU_SUBIR)) return;
  if (WC()->cart->apply_coupon($codigo)) WC()->session->set('t360_amigo', null);
}, 5);
add_filter('woocommerce_coupon_message', function ($mensaje, $codigo_msg, $cupon) {
  return ($cupon && strpos($cupon->get_code(), 'amigo-') === 0) ? 'Descuento de recomendado aplicado: 10 %.' : $mensaje;
}, 10, 3);

// En el correo: el código para recomendar.
add_action('woocommerce_email_after_order_table', function ($order, $admin, $texto_plano, $email) {
  if ($admin || !$email || $email->id !== 'customer_completed_order') return;
  $codigo = t360_crear_codigo_amigo($order);
  if (!$codigo) return;
  if ($texto_plano) {
    echo "\nTU CÓDIGO DE RECOMENDADO: $codigo\nPásaselo a otros tiradores: tendrán un 10 % de descuento (hasta 3 personas). En la app, Inicio › Recomiéndala a otros tiradores.\n\n";
    return;
  }
  echo '<div style="background:#0F2A4A;background-image:linear-gradient(135deg,#123A66,#0B1E3A);border:2px solid #22D3FF;border-radius:16px;padding:22px;margin:24px 0;text-align:center">';
  echo '<p style="margin:0;font-size:13px;letter-spacing:2px;text-transform:uppercase;color:#9DB3C9">🎯 Recomienda y ayuda a tus compañeros</p>';
  echo '<p style="margin:10px 0 4px;font-size:15px;color:#D5E1EE">Tu código de recomendado</p>';
  echo '<p style="margin:0 0 12px;font-family:Consolas,Menlo,monospace;font-size:30px;font-weight:800;letter-spacing:3px;color:#22D3FF">' . esc_html($codigo) . '</p>';
  echo '<p style="margin:0;font-size:15px;color:#D5E1EE"><strong style="color:#F4F7FA">10 % de descuento</strong> para hasta 3 tiradores. Escríbelo en la app, en Inicio › «Recomiéndala a otros tiradores», y envíales el enlace desde ahí.</p></div>';
}, 10, 4);

// ================= Diseño de los correos =================
// La cabecera y el pie están en woocommerce/emails/. Aquí, los colores del contenido (tablas, títulos, enlaces).
add_filter('woocommerce_email_styles', function ($css) {
  return $css . '
#body_content_inner, #body_content_inner p, #body_content_inner li, #body_content_inner td, #body_content_inner th { color:#D5E1EE !important; font-family:"Exo 2","Segoe UI",Helvetica,Arial,sans-serif !important; }
#body_content_inner h2, #body_content_inner h3 { color:#22D3FF !important; font-family:"Exo 2","Segoe UI",Helvetica,Arial,sans-serif !important; font-weight:800 !important; font-size:19px !important; margin:28px 0 12px !important; text-transform:none !important; }
#body_content_inner a { color:#22D3FF !important; }
#body_content_inner strong { color:#F4F7FA !important; }
#body_content_inner table.td, #body_content_inner .td, #body_content_inner table.td th, #body_content_inner table.td td { border:1px solid #1F3A5C !important; background:#0D1D35 !important; }
#body_content_inner table.td { border-radius:12px !important; border-collapse:separate !important; overflow:hidden; }
#body_content_inner tfoot th, #body_content_inner tfoot td { color:#F4F7FA !important; }
#body_content_inner .address { border:1px solid #1F3A5C !important; background:#0D1D35 !important; color:#D5E1EE !important; border-radius:12px !important; padding:14px !important; }
#body_content_inner ol { padding-left:20px !important; }
#body_content_inner code, #body_content_inner .lmfwc-license-key, #body_content_inner table.td td code { font-family:Consolas,Menlo,monospace !important; font-size:17px !important; letter-spacing:1px !important; color:#22D3FF !important; background:#060D18 !important; padding:4px 8px !important; border-radius:6px !important; }
';
});
