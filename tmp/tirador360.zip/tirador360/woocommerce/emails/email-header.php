<?php
/**
 * Cabecera de los correos de la tienda con el diseño de Tirador 360 (fondo oscuro, foto y logo).
 * Sustituye a woocommerce/templates/emails/email-header.php.
 */
if (!defined('ABSPATH')) exit;
$t360_img = get_template_directory_uri() . '/assets/img/';
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=<?php bloginfo('charset'); ?>" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<meta name="color-scheme" content="dark light" />
<meta name="supported-color-schemes" content="dark light" />
<title><?php echo esc_html(get_bloginfo('name', 'display')); ?></title>
</head>
<body <?php echo is_rtl() ? 'rightmargin' : 'leftmargin'; ?>="0" marginwidth="0" topmargin="0" marginheight="0" offset="0" style="margin:0;padding:0;background:#060D18;">
<table width="100%" id="outer_wrapper" role="presentation" cellpadding="0" cellspacing="0" border="0" style="background:#060D18;">
<tr><td align="center" style="padding:24px 12px;">
<div id="wrapper" dir="<?php echo is_rtl() ? 'rtl' : 'ltr'; ?>" style="max-width:640px;margin:0 auto;">
<table border="0" cellpadding="0" cellspacing="0" width="100%" id="template_container" role="presentation" style="background:#0B1626;border:1px solid #1F3A5C;border-radius:18px;overflow:hidden;">
<tr><td align="center" valign="top" style="padding:0;">
<a href="<?php echo esc_url(home_url('/')); ?>" target="_blank" style="display:block;">
<img src="<?php echo esc_url($t360_img . 'email-cabecera.jpg'); ?>" width="640" alt="Tirador 360 · Todo tu tiro deportivo. En un solo lugar." style="display:block;width:100%;max-width:640px;height:auto;border:0;" />
</a>
</td></tr>
<tr><td align="left" valign="top" style="padding:30px 36px 6px;">
<h1 style="margin:0;font-family:'Exo 2','Segoe UI',Helvetica,Arial,sans-serif;font-size:28px;line-height:1.2;font-weight:800;color:#F4F7FA;"><?php echo esc_html($email_heading); ?></h1>
<div style="width:64px;height:4px;border-radius:2px;background:#22D3FF;margin-top:14px;"></div>
</td></tr>
<tr><td align="center" valign="top">
<table border="0" cellpadding="0" cellspacing="0" width="100%" id="template_body" role="presentation">
<tr><td valign="top" id="body_content" style="background:#0B1626;">
<table border="0" cellpadding="20" cellspacing="0" width="100%" role="presentation">
<tr><td valign="top" id="body_content_inner_cell" style="padding:18px 36px 30px;">
<div id="body_content_inner" style="font-family:'Exo 2','Segoe UI',Helvetica,Arial,sans-serif;font-size:16px;line-height:1.6;color:#D5E1EE;text-align:left;">
