<?php
/**
 * Pie de los correos de la tienda con el diseño de Tirador 360.
 * Sustituye a woocommerce/templates/emails/email-footer.php.
 */
if (!defined('ABSPATH')) exit;
$t360_img = get_template_directory_uri() . '/assets/img/';
$t360_pie = wpautop(wp_kses_post(wptexturize(apply_filters('woocommerce_email_footer_text', get_option('woocommerce_email_footer_text')))));
?>
</div>
</td></tr>
</table>
</td></tr>
</table>
</td></tr>
<tr><td style="height:6px;background:#1E6BFF;background-image:linear-gradient(90deg,#1E6BFF,#22D3FF);font-size:0;line-height:0;">&nbsp;</td></tr>
</table>
<table border="0" cellpadding="0" cellspacing="0" width="100%" id="template_footer" role="presentation">
<tr><td align="center" style="padding:26px 20px 10px;">
<img src="<?php echo esc_url($t360_img . 'icono-180.png'); ?>" width="56" height="56" alt="" style="display:block;border:0;border-radius:14px;margin:0 auto 12px;" />
<div style="font-family:'Exo 2','Segoe UI',Helvetica,Arial,sans-serif;font-size:13px;line-height:1.6;color:#9DB3C9;text-align:center;">
<?php echo $t360_pie; // phpcs:ignore WordPress.Security.EscapeOutput ?>
<p style="margin:10px 0 0;">
<a href="<?php echo esc_url(home_url('/')); ?>" style="color:#22D3FF;text-decoration:none;font-weight:700;">Web</a> &nbsp;·&nbsp;
<a href="<?php echo esc_url(home_url('/condiciones-de-venta/')); ?>" style="color:#9DB3C9;">Condiciones de venta</a> &nbsp;·&nbsp;
<a href="<?php echo esc_url(home_url('/privacidad/')); ?>" style="color:#9DB3C9;">Privacidad</a> &nbsp;·&nbsp;
<a href="mailto:rgg@ozono3.es" style="color:#9DB3C9;">Ayuda</a>
</p>
<p style="margin:10px 0 0;font-size:12px;color:#6F87A0;">Soluciones Técnicas y Ambientales de Ozono, S.L.U. · CIF B84718634 · Las Rozas de Madrid</p>
</div>
</td></tr>
</table>
</div>
</td></tr>
</table>
</body>
</html>
