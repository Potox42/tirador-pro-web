<?php
// Páginas normales (aviso legal, privacidad…) y las de WooCommerce (carrito, pago, mi cuenta).
get_header(); ?>
<main class="t360-contenido">
<?php while (have_posts()) : the_post(); ?>
<h1><?php the_title(); ?></h1>
<?php the_content(); ?>
<?php endwhile; ?>
</main>
<?php get_footer();
