<?php
if (!defined('ABSPATH')) exit;

add_action('after_setup_theme', function () {
  add_theme_support('title-tag');
  add_theme_support('woocommerce');
  add_theme_support('html5', ['search-form', 'comment-form', 'gallery', 'caption', 'style', 'script']);
  register_nav_menus(['principal' => 'Menú principal']);
});

add_action('wp_enqueue_scripts', function () {
  wp_enqueue_style('t360-fuente', 'https://fonts.googleapis.com/css2?family=Exo+2:wght@400;500;600;700;800&display=swap', [], null);
  wp_enqueue_style('t360', get_stylesheet_uri(), [], wp_get_theme()->get('Version'));
});

// Icono de la web y del iPhone.
add_action('wp_head', function () {
  $u = get_template_directory_uri() . '/assets/img/';
  echo '<link rel="icon" type="image/svg+xml" href="' . esc_url($u . 'icono.svg') . "\">\n";
  echo '<link rel="apple-touch-icon" href="' . esc_url($u . 'icono-180.png') . "\">\n";
  echo "<meta name=\"theme-color\" content=\"#060D18\">\n";
});

// Mientras la web esté en la dirección provisional, que Google no la indexe.
// Al pasar a tirador360.es, cambiar a false.
const T360_EN_OBRAS = true;
add_action('wp_head', function () {
  if (T360_EN_OBRAS) echo "<meta name=\"robots\" content=\"noindex,nofollow\">\n";
}, 1);
