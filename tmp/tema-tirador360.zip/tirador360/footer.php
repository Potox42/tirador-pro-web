<footer class="t360-pie"><div class="dentro">
<img src="<?php echo esc_url(get_template_directory_uri() . '/assets/img/logo-horizontal-oscuro.svg'); ?>" alt="Tirador 360" style="height:40px;width:auto">
<span>© <?php echo esc_html(date('Y')); ?> Tirador 360</span>
</div></footer>
<?php wp_footer(); ?>
</body>
</html>
