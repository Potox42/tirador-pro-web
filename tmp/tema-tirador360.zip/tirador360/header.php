<!doctype html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo('charset'); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<header class="t360-cab"><div class="dentro">
<a href="<?php echo esc_url(home_url('/')); ?>"><img src="<?php echo esc_url(get_template_directory_uri() . '/assets/img/logo-horizontal-oscuro.svg'); ?>" alt="Tirador 360" style="height:44px;width:auto;display:block"></a>
<nav aria-label="Principal">
<a href="<?php echo esc_url(home_url('/#app')); ?>">La app</a>
<a href="<?php echo esc_url(home_url('/#precio')); ?>">Precio</a>
<a href="<?php echo esc_url(home_url('/#preguntas')); ?>">Preguntas</a>
</nav>
</div></header>
